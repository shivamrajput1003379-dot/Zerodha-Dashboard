import React, { useState, useContext, useEffect } from "react";
import { Tooltip, Grow } from "@mui/material";
import {
  BarChartOutlined,
  KeyboardArrowDown,
  KeyboardArrowUp,
  MoreHoriz,
} from "@mui/icons-material";
import { watchlist as staticWatchlist } from "../data/data";
import GeneralContext from "./GeneralContext";
import {DoughnutChart} from "./DoughnoutChart";

const WatchList = () => {
  const [liveWatchlist, setLiveWatchlist] = useState(staticWatchlist);

  useEffect(() => {
    let isMounted = true;

    const fetchLivePrices = async () => {
      try {
        const symbols = staticWatchlist.map((stock) => stock.name);

        const response = await fetch(
          "https://zerodha-backend-o227.onrender.com/api/watchlist-prices",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ symbols }),
          }
        );

        if (!response.ok) return;
        const livePrices = await response.json();

        if (!isMounted) return;

        setLiveWatchlist((prev) =>
          prev.map((stock) => {
            const updated = livePrices.find((p) => p.name === stock.name);
            if (!updated) return stock;

            return {
              ...stock,
              price: updated.price ?? stock.price,
              percent: updated.day ?? updated.percent ?? stock.percent,
              isDown: updated.isLoss ?? updated.isDown ?? stock.isDown,
            };
          })
        );
      } catch (err) {
        console.error("Live price update error:", err);
      }
    };

    fetchLivePrices();
    const intervalId = setInterval(fetchLivePrices, 4000);

    return () => {
      isMounted = false;
      clearInterval(intervalId);
    };
  }, []);

  const labels = liveWatchlist.map((subArray) => subArray["name"]);

  const data = {
    labels,
    datasets: [
      {
        label: "Price",
        data: liveWatchlist.map((stock) => stock.price),
        backgroundColor: [
          "rgba(255, 99, 132, 0.5)",
          "rgba(54, 162, 235, 0.5)",
          "rgba(255, 206, 86, 0.5)",
          "rgba(75, 192, 192, 0.5)",
          "rgba(153, 102, 255, 0.5)",
          "rgba(255, 159, 64, 0.5)",
        ],
        borderColor: [
          "rgba(255, 99, 132, 1)",
          "rgba(54, 162, 235, 1)",
          "rgba(255, 206, 86, 1)",
          "rgba(75, 192, 192, 1)",
          "rgba(153, 102, 255, 1)",
          "rgba(255, 159, 64, 1)",
        ],
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="watchlist-container">
      <div className="search-container">
        <input
          type="text"
          name="search"
          id="search"
          placeholder="Search eg:infy, bse, nifty fut weekly, gold mcx"
          className="search"
        />
        <span className="counts"> {liveWatchlist.length} / 50</span>
      </div>

      <ul className="list">
        {liveWatchlist.map((stock, index) => {
          return <WatchListItem stock={stock} key={stock.name || index} />;
        })}
      </ul>

      <DoughnutChart data={data} />
    </div>
  );
};

const WatchListItem = ({ stock }) => {
  const [showWatchlistActions, setShowWatchlistActions] = useState(false);

  return (
    <li
      onMouseEnter={() => setShowWatchlistActions(true)}
      onMouseLeave={() => setShowWatchlistActions(false)}
    >
      <div className={`item ${showWatchlistActions ? "item-hovered" : ""}`}>
        <p className={stock.isDown ? "down" : "up"}>{stock.name}</p>
        <div className="item-info">
          <span className="percent">{stock.percent}</span>
          {stock.isDown ? (
            <KeyboardArrowDown className="down" />
          ) : (
            <KeyboardArrowUp className="up" />
          )}
          <span className="price">{stock.price}</span>
        </div>
      </div>
      {showWatchlistActions && <WatchListActions uid={stock.name} />}
    </li>
  );
};

const WatchListActions = ({ uid }) => {
  const { openBuyWindow } = useContext(GeneralContext);

  return (
    <span className="actions">
      <span>
        <Tooltip title="Buy (B)" placement="top" arrow TransitionComponent={Grow}>
          <button className="buy" onClick={() => openBuyWindow(uid)}>
            Buy
          </button>
        </Tooltip>
        <Tooltip title="Sell (S)" placement="top" arrow TransitionComponent={Grow}>
          <button className="sell">Sell</button>
        </Tooltip>
        <Tooltip title="Analytics (A)" placement="top" arrow TransitionComponent={Grow}>
          <button className="action">
            <BarChartOutlined className="icon" />
          </button>
        </Tooltip>
        <Tooltip title="More" placement="top" arrow TransitionComponent={Grow}>
          <button className="action">
            <MoreHoriz className="icon" />
          </button>
        </Tooltip>
      </span>
    </span>
  );
};

export default WatchList;